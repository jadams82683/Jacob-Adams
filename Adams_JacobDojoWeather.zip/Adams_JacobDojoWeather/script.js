function hideCookie() {
    cookiesection.remove();
}

var tempButton=document.querySelector("#CtoF") 
var firstF=document.querySelector("#firsthighF")
var firstLF=document.querySelector("#firstlowF")
var secondF=document.querySelector("#secondhighF")
var secondLF=document.querySelector("#secondlowF")
var thirdF=document.querySelector("#thirdhighF")
var thirdLF=document.querySelector("#thirdlowF")
var fourthF=document.querySelector("#fourthhighF")
var fourthLF=document.querySelector("#fourthlowF")

function changeTemp () {
    tempButton.innerText = "°F"
    firstF.innerText = "75°"
    firstLF.innerText = "65°"
    secondF.innerText = "80°"
    secondLF.innerText = "66°"
    thirdF.innerText = "69°"
    thirdLF.innerText = "61°"
    fourthF.innerText = "78°"
    fourthLF.innerText = "70°"
}

var firstF=document.querySelector("#firsthighF")

