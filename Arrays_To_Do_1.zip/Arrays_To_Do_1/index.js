function pushFront (array, num) {
    for (var j = array.length; j >= 0; j --) {
        array[j] = array[j -1]
    }
    array[0] = num;
    return array;
}

console.log(pushFront([5, 4, 3, 2, 1], 8));

function popFront(array) {
    var num = array[0]
    for (var k = 0; k < array.length - 1; k ++) {
        array[k] = array[k + 1]
    }
    array.length = array.length - 1;
    console.log(array);
    return num;
}

console.log(popFront([4, 5, 6, 7, 8]));

function insertAt(array, index, num) {
    for (var z = array.length; z >= index; z --) {
        array[z] = array[z - 1]
    }
    array[index] = num;
    return array;
}

console.log(insertAt([3, 3, 3, 3, 3], 2, 44));