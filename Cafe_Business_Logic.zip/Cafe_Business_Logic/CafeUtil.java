import java.util.Date;
import java.util.ArrayList;

public class CafeUtil {

    public int getStreakGoal(int numWeek) {
        int sum = 0;

        for(int week = 1; week <= numWeek; week ++) {
            sum += week;
        }
        return sum;
    }

    public double getOrderTotal(double [] lineItems) {

        double sum = 0;
        for(double item: lineItems) {
            sum += item;
        }
        return sum;
    }

    public void displayMenu(ArrayList<String> menu) {

        for(int id = 0; id < menu.size(); id ++) {
            System.out.printf("Item %s is %s: ", id, menu.get(id));
        }
    }

    public void addCustomer(ArrayList<String> customers) {
        System.out.println("Please enter your name:");
        String userName = System.console().readLine();
        System.out.printf("Hello %s!", userName);
        System.out.printf("There are %s people ahead of you", customers.size());
        customers.add(userName);
        System.out.println(customers);
    }
}