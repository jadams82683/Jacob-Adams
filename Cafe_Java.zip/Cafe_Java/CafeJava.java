public class CafeJava {
    public static void main(String[] args) {

        String generalGreeting = "Welcome to Cafe Java, ";
        String pendingMessage = ", your order will be ready shortly";
        String readyMessage = ", your order is ready"; 
        String displayTotalMessage = "Your total is $";

        double mochaPrice = 4.5;
        double DripCoffee = 2.15;
        double Latte = 4.75;
        double Cappucino = 4.15;

        String customer1 = "Cindhuri";
        String customer2 = "Sam";
        String customer3 = "Jimmy";
        String customer4 = "Noah";

        boolean isReadyOrder1 = true;
        boolean isReadyOrder2 = false;
        boolean isReadyOrder3 = true;
        boolean isReadyOrder4 = false;

        System.out.println(generalGreeting + customer1);
        System.out.println(isReadyOrder1);

        if(isReadyOrder4) {
            System.out.println(Cappucino);
        }
        else {
            System.out.println("Your order isn't quite ready yet.");
        }

        System.out.println(Latte * 2);
        if(isReadyOrder2) {
            System.out.println("Your order is ready!");
        }
        else {
            System.out.println("Not quite ready yet. Just a few more minutes.");
        }

        System.out.println(Latte - DripCoffee);

        
    }
}