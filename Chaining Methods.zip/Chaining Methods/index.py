class User:
    def __init__(self, first_name, last_name, age, email):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.account_balance = 0 

    def make_deposit(self, amount):
        self.account_balance += amount
        print(self.account_balance)
        return self

    def make_withdrawl(self, amount):
        self.account_balance -= amount
        print(self.account_balance)
        return self

    def display_user_balance(self):
        print(f"User: {self.first_name} {self.last_name}, Balance: {self.account_balance}")
        return self

    def transfer_money(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount
        return self

Jacob = User("Jacob", "Adams", "38", "jacobadams83@gmail.com")
Wolfgang = User("Wolfgang", "Mozart", "35", "wolfie@composers.com")
Ludwig = User("Ludwig van", "Beethoven", "56", "ludwig@composer.com")

Jacob.make_deposit(100).make_deposit(1500).make_deposit(2200).make_withdrawl(500).display_user_balance()

Wolfgang.make_deposit(2300).make_deposit(4600).make_withdrawl(1500).make_withdrawl(700).display_user_balance()

Ludwig.make_deposit(6600).make_withdrawl(1100).make_withdrawl(300).make_withdrawl(400).display_user_balance()

Jacob.transfer_money(Ludwig, 200).display_user_balance()

Ludwig.display_user_balance()