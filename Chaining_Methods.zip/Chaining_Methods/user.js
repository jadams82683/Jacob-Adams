class User {
    constructor(userName, emailAddress) {
        this.name = userName
        this.email = emailAddress
        this.accountBalance = 0

    }
    makeDeposit(amount) {
        this.accountBalance += amount;
        return this;
    }
    makeWithdrawl(amount) {
        this.accountBalance -= amount;
        return this;
    }
    
    displayBalance() {
        console.log(`Name: ${this.name}, Account Balance: $${this.accountBalance}`);
        return this;
    }

    transferMoney(amount, otherUser) {
        this.accountBalance -= amount;
        otherUser.accountBalance += amount;
        return this;
    }
}
const Wolfgang = new User("Wolfgang", "wolfie@composers.com");
const Sergei = new User("Sergei", "pokey@composers.com");
const Frederick = new User("Frederick", "freddy@composers.com");

Sergei.makeDeposit(1000).makeDeposit(2000).makeWithdrawl(500).makeWithdrawl(500).displayBalance();

Frederick.makeDeposit(5000).makeWithdrawl(400).makeWithdrawl(300).makeWithdrawl(200).displayBalance();

Wolfgang.transferMoney(1000, Sergei).displayBalance();
Sergei.displayBalance();