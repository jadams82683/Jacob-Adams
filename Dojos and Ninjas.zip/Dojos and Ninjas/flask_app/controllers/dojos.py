from flask import render_template, redirect, request, session
from flask_app import app #importing the Flask class from the flask_app folder
from flask_app.models.dojo import Dojo #importing the Dojo class from the dojo file in models folder

@app.route('/')#root route - same as 'localhost:5000'
def index(): #name of function that is performed when this route is called in the url
    return redirect ('/dojos')#immediately takes user to the 'dojos' route

@app.route('/dojos')
def display_dojos ():
    dojos = Dojo.get_all() #assigning dojos variable to the results of the get_all method of Dojo class
    return render_template("index.html", all_dojos = dojos)#all_dojos is the variable that will get passed into the html file, equal to dojos

@app.route('/create/dojo', method = ['POST'])
def make_new_dojo():
    Dojo.save_dojo(request.form)#calling save function from Dojo class. Passes the info saved from the request.form over to it
    return redirect('/dojos')

@app.route('/dojo/<int:id>')#this url uses a path variable, called id
def show_dojo(id): #the function requires that the path variable from the url be passed into the function as an argument
    info = {
        'id': dojo_id
    }
    return render_template('dojo.html', dojo = Dojo.get_dojo_with_ninjas(info))
    #the return function displays the dojo.html page. The dojo variable is what gets passed into the html and is equal to the value of the 
    #result of the get_dojo_with_ninjas function of the Dojo class. The info argument is the dictionary which is from the id path variable