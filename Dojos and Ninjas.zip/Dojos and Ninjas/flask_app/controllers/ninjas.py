from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models import dojo, ninja #importing dojo & ninja files from models folder, so that this file can access the classes

@app.route('/ninjas')
def display_ninjas():
    return render_template('ninja.html', dojos = dojo.Dojo.get_all)

@app.route('/create/ninja', method = ['POST'])
def make_new_ninja():
    ninja.Ninja.save_ninja(request.form) #this is calling the save function from the Ninja class and passing in ther request.form info, which is the info being put in to the html form
    return redirect ('/') #will take the user back to the root route upon clicking the submit button (which first does the post request to process the data)