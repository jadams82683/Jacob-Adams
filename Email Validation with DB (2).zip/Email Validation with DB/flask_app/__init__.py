from flask import Flask, session

app = Flask(__name__)

app.secret_key = "999888777666555444333222111"