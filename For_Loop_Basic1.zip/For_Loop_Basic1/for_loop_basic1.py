for x in range(0, 151):
    print(x)

for x in range(5, 1001, 5):
        print(x)

for x in range(1, 101):
    if x % 5 == 0 and x % 10 != 0:
        print("Coding")
    elif x % 10 == 0:
        print("Coding Dojo")
    else:
        print(x)

sum = 0    
for i in range(0, 500001):
    if i % 2 != 0:
        sum += i
print(sum)

for i in range(2018, -1, -4):
    print(i)

lowNum = 3
highNum = 21
mult = 4
for i in range(lowNum, highNum):
    if i % mult == 0:
        print(i)
    

