def countdown(num):
    List = []
    for i in range(num, -1, -1):
        List.append(i)
    return List

print(countdown(5))

def print_and_return(a, b):
    newList = [a, b]
    print(a)
    return b

print(print_and_return(1, 2))

def first_plus_length(newList2):
    sum = newList2[0] + len(newList2)
    return sum

print(first_plus_length([11, 13, 15, 17, 19, 21, 23, 29]))

def values_greater_than_second(newList3):
    newList4 = []
    if len(newList3) < 2:
        print("False")
    for i in range(len(newList3)):
        if newList3[i] > newList3[1]:
            newList4.append(newList3[i])
    print(len(newList4))
    return newList4

print(values_greater_than_second([5, 2, 3, 2, 1, 4]))

def length_and_value(size, value):
    newList5 = []
    for i in range(size):
        newList5.append(value)
    return newList5

print(length_and_value(4, 7))
print(length_and_value(7, 11))






