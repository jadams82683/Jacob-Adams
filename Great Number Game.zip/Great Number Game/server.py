from flask import Flask, render_template, redirect, request, session
import random
app = Flask(__name__)
app.secret_key = "777666555666777"

@app.route('/')
def random_num():
    if "num" not in session:
        session["num"] = random.randint(1, 100)
    return render_template ("index.html")


@app.route('/submit', method = ["POST"])
def check_guess():
    session['num_guess'] = int(request.form['guess'])
    return redirect('/')

@app.route('/reset')
def reset_game():
    session.clear()
    return redirect ('/')

if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)