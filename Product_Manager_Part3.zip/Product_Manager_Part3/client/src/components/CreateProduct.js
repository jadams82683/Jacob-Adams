import React, {useState} from 'react';
import axios from 'axios';

const CreateProduct = (props) => {

    const {productList, setProductList} = props;
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    const submitHandler = (event) => {
        event.preventDefault();

        axios.post("http://localhost:8000/api/products", {
            title: title,
            price: price,
            description: description,
        })
        .then((response) => {
            console.log(response);
            console.log(response.data);
            setProductList([...productList, response.data]);
            setTitle("");
            setPrice("");
            setDescription("");
        })
        .catch((err) => console.log(err));
    };

    return (
        <div>
            <header>Jacob's Product Manager!!! Wow!!!</header>
            <form onSubmit = {submitHandler}>
                <div>
                    <label>Name of Product:</label>
                    <input type = "text" name = "title" value = {title} onChange = {(e) => setTitle(e.target.value)}/>
                </div>
                <br/>
                <div>
                    <label>Price of Product:</label>
                    <input type = "number" name = "price" value = {price} onChange = {(e) => setPrice(e.target.value)}/>
                </div>
                <br/>
                <div>
                    <label>Description of Product:</label>
                    <input type = "text" name = "description" value = {description} onChange = {(e) => setDescription(e.target.value)}/>
                </div>
                <br/>
                <input type = "submit" value = "Create New Product"/>
            </form>
        </div>
    );

};

export default CreateProduct;