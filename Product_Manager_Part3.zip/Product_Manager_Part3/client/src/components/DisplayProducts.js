import React, {useEffect} from 'react';
import axios from 'axios';
import {Link, useNavigate} from "react-router-dom"

const DisplayProducts = (props) => {

    const {productList, setProductList} = props;
    const navigate = useNavigate();

    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then((response) => {
                console.log(response.data);
                setProductList(response.data);
            })
            .catch((err) => console.lorg(err));
    }, []);

    const deleteFilter = (idFromBelow) => {
        axios.delete(`http://localhost:8000/api/products/${idFromBelow}`)
            .then((response) => {
                console.log(response.data);
                const newList = productList.filter((product, index) => product._id !== idFromBelow)
                setProductList(newList);
            })
            .catch((err) => console.log(err));
    };

    return (
        <div>
            <header>All of Jacob's Amazing Products:</header>
            {
                productList.map((product, index) => (
                    <div key = {index}>
                        <Link to = {`/product/${product._id}`}>{product.title}</Link>
                        <br/>
                        <button onClick = {() => navigate(`/product/edit/${product._id}`)}>Edit Product</button>
                        <button onClick={() => deleteFilter(product._id)}>Delete Product</button>
                    </div>
                ))
            }
        </div>
    );
};

export default DisplayProducts;