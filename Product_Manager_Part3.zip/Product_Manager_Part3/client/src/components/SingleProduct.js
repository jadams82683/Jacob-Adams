import React, {useState, useEffect} from 'react';
import {useNavigate, useParams} from 'react-router-dom';
import axios from 'axios';

const SingleProduct = (props) => {
    const {id} = useParams();
    const navigate = useNavigate();
    const [oneProduct, setOneProduct] = useState({});

    useEffect(() => {
        axios.get(`http://localhost:8000/api/products/${id}`)
            .then((response) => {
                console.log(response.data);
                setOneProduct(response.data);
            })
            .catch((err) => console.log(err));
    }, [id]);

    const deleteHandler = () => {
        axios.delete(`http://localhost:8000/api/products/${id}`)
            .then((response) => {
                console.log(response);
                console.log(response.data);
                navigate("/");
            })
            .catch((err) => {console.log(err);
    });
    };

    return (
        <div>
            <h1>{oneProduct.title}</h1>
            <h2>Price: {oneProduct.price}</h2>
            <h2>Description: {oneProduct.description}</h2>
            <button onClick={deleteHandler}>Delete Product</button>
        </div>
    );
};

export default SingleProduct;