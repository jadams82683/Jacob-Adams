import React, {useState, useEffect} from 'react';
import {useNavigate, useParams} from "react-router-dom";
import axios from 'axios';

const UpdateProduct = (props) => {
    const {id} = useParams();
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");
    const navigate = useNavigate();
    const [headerTitle, setHeaderTitle] = useState("");

    useEffect(() => {
        axios.get(`http://localhost:8000/api/products/${id}`)
            .then((response) => {
                console.log(response.data);
                setTitle(response.data.title);
                setPrice(response.data.price);
                setDescription(response.data.description);
                setHeaderTitle(response.data.Title)
            })
            .catch((err) => console.log(err));
    }, []);

    const submitHandler = (event) => {
        event.preventDefault();
        axios.put(`http://localhost:8000/api/products/${id}`, {
            title: title, 
            price: price, 
            description: description,
    })
        .then((response) => {
            console.log(response);
            console.log(response.data);
            navigate("/");
        })
        .catch((err) => console.log(err));
};

    return (
        <div>
            <header>Edit {headerTitle}</header>
            <form onSubmit={submitHandler}>
                <div>
                    <label>Name of Product:</label>
                    <input type = "text" name = "title" value = {title} onChange = {(e) => setTitle(e.target.value)}/>
                </div>
                <br/>
                <div>
                    <label>Price of Product:</label>
                    <input type = "number" name = "price" value = {price} onChange = {(e) => setPrice(e.target.value)}/>
                </div>
                <br/>
                <div>
                    <label>Description of Product:</label>
                    <input type = "text" name = "description" value = {description} onChange = {(e) => setDescription(e.target.value)}/>
                </div>
                <br/>
                <input type = "submit" value = "Update Product"/>
            </form>
        </div>
    );

};

export default UpdateProduct;