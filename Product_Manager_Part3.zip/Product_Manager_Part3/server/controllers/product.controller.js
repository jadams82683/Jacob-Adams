const Product = require("../models/product.model.js");

module.exports = {

    getAllProducts: (request, response) => {
        Product.find({}) 
            .then((allProducts) => response.json(allProducts))
            .catch((err) => console.log(err));
    },

    getOneProduct: (request, response) => {
        Product.findOne({_id: request.params.id})
            .then((oneProduct) => response.json(oneProduct))
            .catch((err) => console.log(err));
    },

    createProduct: (request, response) => {
        Product.create(request.body) 
            .then((newProduct) => response.json(newProduct))
            .catch((err) => console.log(err));
    },

    updateProduct: (request, response) => {
        Product.findByIdAndUpdate({_id: request.params.id}, request.body, {
            new: true,
            runValidators: true,
        }) 
            .then((updatedProduct) => response.json(updatedProduct))
            .catch((err) => console.log(err));
    },

    deleteProduct: (request, response) => {
        Product.deleteOne({_id: request.params.id})
        .then((deletedProduct) => response.json(deletedProduct))
        .catch((err) => console.log(err));
    },
};