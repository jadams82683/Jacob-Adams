num1 = 42 #variable declaration
num2 = 2.3  #variable declaration
boolean = True #data type, boolean
string = 'Hello World' #variable declaration, data type string
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] #list declared 
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False} #dictionary, boolean
fruit = ('blueberry', 'strawberry', 'banana') #tuple, variable declaration
print(type(fruit)) #log statement, logging tuple
print(pizza_toppings[1]) #log statement, list, access value, index
pizza_toppings.append('Mushrooms') #add value to list
print(person['name']) # access value, value of 'name' key
person['name'] = 'George' #change value, changing value of 'name' key from 'John' to 'George'
person['eye_color'] = 'blue' # adding key-value pair to dictionary
print(fruit[2]) #tuple, accessing index 2

if num1 > 45:
    print("It's greater") #will print statement if num1 is greater than 45
else:
    print("It's lower") #conditional, if-else statement

if len(string) < 5:
    print("It's a short word!") #will print this statement if the length of 'string' is less than 5
elif len(string) > 15:
    print("It's a long word!") #will print this statement if the lenght of 'string' is greater than 15
else:
    print("Just right!") #conditional, if/elif/else statement. Will print this if neither of the above conditions are met

for x in range(5):
    print(x) #for loop, will run x five times
for x in range(2,5):
    print(x) # for loop, will run x starting at 2 and going until it reaches 5
for x in range(2,10,3):
    print(x) #for loop, will run x starting at 2 going up until 10 and in increments of 3
x = 0 #variable declaration
while(x < 5):
    print(x)
    x += 1 #while loop, will run x as long as it's less than, x will increment by 1

pizza_toppings.pop() #will get rid of last value in list
pizza_toppings.pop(1) #will get rid of 

print(person) #will print the person dictionary
person.pop('eye_color') #will get rid of the 'eye-color' key of the person dictionary
print(person) #will now print the updated person dictionart

for topping in pizza_toppings: #for each item in pizza_toppings list, run the code below
    if topping == 'Pepperoni': #if code reaches 'Pepperoni' item, get out of loop and continue with the rest of the code
        continue
    print('After 1st if statement') #will print this message after reaching 'Pepperoni'
    if topping == 'Olives':
        break #will break code block entirely once reaching 'Olives' and continue to the next line

def print_hello_ten_times(): #defining a function
    for num in range(10): #run the code below each time num is 1-10
        print('Hello') #will print 'Hello' ten times

print_hello_ten_times() #invoking/calling a function

def print_hello_x_times(x): #defining a function. x is a parament
    for num in range(x): #logic of function. x can be any number that gets passed in as an argument
        print('Hello') #will print 'Hello' however many times 

print_hello_x_times(4) #invoking the function. Will print 'Hello' 4 times. 4 is an argument

def print_hello_x_or_ten_times(x = 10): #defining a function. x is set to 10 as a default
    for num in range(x): #logic of function. num is in range of 1 and whatever is assigned to x. 
        print('Hello') # will print "Hello" whatever x is

print_hello_x_or_ten_times() #will print 'Hello' 10 times since x isn't defined and 10 is its default
print_hello_x_or_ten_times(4) #will print 'Hello' 4 times


"""
Bonus section
"""

# print(num3)
# num3 = 72
# fruit[0] = 'cranberry'
# print(person['favorite_team'])
# print(pizza_toppings[7])
#   print(boolean)
# fruit.append('raspberry')
# fruit.pop(1)

- variable declaration
- log statement
- type check
- length check
- comment
    - single line
    - multiline
- Data Types
    - Primitive
        - Boolean
        - Numbers
        - Strings
    - Composite
        - List 
            - initialize
            - access value
            - change value
            - add value
            - delete value
        - Tuples
            - initialize
            - access value
            - change value
            - add value
            - delete value
        - Dictionary
            - initialize
            - access value
            - change value
            - add value
            - delete value
- conditional
    - if
    - else if
    - else
- for loop
    - start
    - stop
    - increment
    - break
    - continue
    - sequence
- while loop
    - start
    - stop
    - increment
- function
    - parameter
    - argument
    - return

* Bonus: Errors

- NameError: name <variable name> is not defined
- TypeError: 'tuple' object does not support item assignment
- KeyError: 'favorite_team'
- IndexError: list index out of range
- IndentationError: unexpected indent
- AttributeError: 'tuple' object has no attribute 'pop'
- AttributeError: 'tuple' object has no attribute 'append'
- Tuples
    - change value
    - add value
    - delete value