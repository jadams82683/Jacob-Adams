class Store:
    def __init__(self, name, products):
        self.name = name
        self.products = []

    def add_product(self, new_product):
        self.products.append(new_product)
        return self

    def sell_product(self, id):
        self.products.pop[id]
        print(self.products)
        return self

class Product:
    def __init__(self, name, price, category):
        self.name = name
        self.price = price
        self.category = category

    def update_price(self, percentage_change, is_increased):
        if is_increased == True:
            self.price += self.price * percentage_change
        if is_increased == False:
            self.price -= self.price * percentage_change
        print(self.price)
        return self

    def print_info(self):
        print(self.name, self.price, self.category)
        return self

    
Target = Store("Target", )
