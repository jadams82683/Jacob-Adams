class BankAccount {
    constructor(intRate = 0.08, balance = 1500) {
        this.intRate = intRate;
        this.balance = balance;
    }
    deposit(amount) {
        this.balance += amount;
        return this;
    }

    withdraw(amount) {
        this.balance -= amount;
        if (this.balance < 0) {
            console.log("Insufficient funds to proceed with this transaction.")
        }
        return this;
    }
    displayAccountInfo() {
        console.log(`Account balance is currently ${this.balance}`);
        return this;
    }

    yieldInterest() {
        this.balance += this.balance * this.intRate;
        return this;
    }  
}

class User {
    constructor(name, email) {
        this.name = name;
        this.email = email;
        this.account = new BankAccount();
    }

    makeDeposit(amount) {
        this.account.deposit(amount);
        return this;
    }

    makeWithdrawl(amount) {
        this.account.withdraw(amount);
        return this;
    }

    displayInfo() {
        console.log(`User Name: ${this.name}. Balance: ${this.account.balance}. Interest rate: ${this.account.intRate}`);
        return this;
    }
}
const Jacob = new User("Jacob", "jacobadams83@gmail.com");
const Sarah = new User("Sarah", "sburlingham@yahoo.com"); 

Jacob.makeDeposit(1000).makeDeposit(1000).makeDeposit(1000).displayInfo();
Sarah.makeDeposit(2000).makeDeposit(2000).makeWithdrawl(1000).makeWithdrawl(1000).displayInfo();



