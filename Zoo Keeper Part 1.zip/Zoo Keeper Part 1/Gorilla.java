public class Gorilla extends Mammal {

	public Gorilla(int energyLevel) {
		super(energyLevel);
	}

	public void throwSomething() {
		System.out.println("I have just thrown something, like gorillas often do.");
		energyLevel -= 5;
	}
	public void eatBanana() {
		System.out.println("Boy, I sure love bananas. Great source of potassium too.");
		energyLevel += 10;
	}
	public void climb() {
		System.out.println("Climbing is fun. I especially like climbing trees.");
		energyLevel -= 10;
	}
}