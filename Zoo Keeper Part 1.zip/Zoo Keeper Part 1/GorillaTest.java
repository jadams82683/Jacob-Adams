public class GorillaTest {

    public static void main(String[] args) {
        
        Gorilla George = new Gorilla(100);

        System.out.println(George.energyLevel);

        George.throwSomething();
        George.throwSomething();
        George.throwSomething();
        George.eatBanana();
        George.eatBanana();
        George.climb();

        System.out.println(George.energyLevel);
    }
}
    

    


