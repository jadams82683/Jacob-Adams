public class Mammal {

    public int energyLevel = 100;

    public int getEnergyLevel() {
        System.out.println("Your Energy Level is:" + energyLevel);
        return energyLevel;
    }

    public Mammal(int energyLevel) {
        this.energyLevel = energyLevel;
    }
}